package workflow

sealed class TriggerDefinition {

    data class Cron(
        val id: String,
        val expression: String
    ) : TriggerDefinition()
}
