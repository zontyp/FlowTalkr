package workflow

data class WorkflowDefinition(
    val id:String,
    val start: String,
    val nodes: List<NodeDefinition>,
    val triggers: List<TriggerDefinition> = emptyList()
)
