package engine

enum class StateAccess {
    STATELESS,
    READS_STATE
}
