package nodes

enum class Operator {
    EQUALS,
    NOT_EQUALS
}
